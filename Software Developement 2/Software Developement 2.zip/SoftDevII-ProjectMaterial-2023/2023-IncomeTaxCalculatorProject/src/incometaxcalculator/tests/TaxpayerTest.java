package incometaxcalculator.tests;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;

import org.junit.jupiter.api.Test;

import incometaxcalculator.data.management.TaxpayerManager;
import incometaxcalculator.exceptions.WrongFileEndingException;
import incometaxcalculator.exceptions.WrongFileFormatException;
import incometaxcalculator.exceptions.WrongReceiptDateException;
import incometaxcalculator.exceptions.WrongReceiptKindException;
import incometaxcalculator.exceptions.WrongTaxpayerStatusException;

class TaxpayerTest {

  @Test
  void testCalculateBasicTax() throws WrongTaxpayerStatusException, NumberFormatException, IOException, WrongFileFormatException, WrongFileEndingException, WrongReceiptKindException, WrongReceiptDateException {
    TaxpayerManager testTaxpayerManager = new TaxpayerManager();
    testTaxpayerManager.loadTaxpayer("123456789_INFO.txt");
    assertEquals(1207.495, testTaxpayerManager.getTaxpayerHashMapEntryValue().calculateBasicTax());
  }

}
