package incometaxcalculator.tests;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;

import org.junit.jupiter.api.Test;

import incometaxcalculator.data.management.Taxpayer;
import incometaxcalculator.data.management.TaxpayerManager;
import incometaxcalculator.exceptions.WrongFileEndingException;
import incometaxcalculator.exceptions.WrongFileFormatException;
import incometaxcalculator.exceptions.WrongReceiptDateException;
import incometaxcalculator.exceptions.WrongReceiptKindException;
import incometaxcalculator.exceptions.WrongTaxpayerStatusException;

class TaxpayerManagerTest {

  @Test
  void testCreateTaxpayerSingle() throws WrongTaxpayerStatusException {
    TaxpayerManager testTaxpayerManager = new TaxpayerManager();
    testTaxpayerManager.createTaxpayer("Tester Tester", 123456789, "Single", 999);
    assertEquals(testTaxpayerManager.getTaxpayerHashMapEntryValue(), testTaxpayerManager.getNewTaxpayer() );
  }

  @Test
  void testCreateTaxpayerMarriedFilingJointly() throws WrongTaxpayerStatusException {
    TaxpayerManager testTaxpayerManager = new TaxpayerManager();
    testTaxpayerManager.createTaxpayer("Tester Tester2", 123456789, "Married Filing Jointly", 999);
    assertEquals(testTaxpayerManager.getTaxpayerHashMapEntryValue(), testTaxpayerManager.getNewTaxpayer() );
  }
  
  @Test
  void testCreateTaxpayerMarriedFilingSeparately() throws WrongTaxpayerStatusException {
    TaxpayerManager testTaxpayerManager = new TaxpayerManager();
    testTaxpayerManager.createTaxpayer("Tester Tester3", 123456789, "Married Filing Separately", 999);
    assertEquals(testTaxpayerManager.getTaxpayerHashMapEntryValue(), testTaxpayerManager.getNewTaxpayer() );
  }
  
  @Test
  void testCreateTaxpayerHeadOfHousehold() throws WrongTaxpayerStatusException {
    TaxpayerManager testTaxpayerManager = new TaxpayerManager();
    testTaxpayerManager.createTaxpayer("Tester Tester4", 123456789, "Head of Household", 999);
    assertEquals(testTaxpayerManager.getTaxpayerHashMapEntryValue(), testTaxpayerManager.getNewTaxpayer() );
  }
  
  @Test
  void testCreateReceipt() throws WrongTaxpayerStatusException, 
  NumberFormatException, IOException, WrongFileFormatException, 
  WrongFileEndingException, WrongReceiptKindException, WrongReceiptDateException {
    TaxpayerManager testTaxpayerManager = new TaxpayerManager();
    testTaxpayerManager.loadTaxpayer("123456789_INFO.txt");
    testTaxpayerManager.createReceipt(999, "10/10/2010", 5, "Basic",
      "Some Company", "Somewhere", "Somewhere", "Somewhere", 10,
      123456789);
    assertEquals(999, testTaxpayerManager.getTaxpayerHashMapEntryValue().getReceiptHashMap().get(999).getId());
  }
  
  @Test
  void testRemoveReceipt() throws NumberFormatException, 
  IOException, WrongFileFormatException, WrongFileEndingException, 
  WrongTaxpayerStatusException, WrongReceiptKindException, WrongReceiptDateException {
    TaxpayerManager testTaxpayerManager = new TaxpayerManager();
    testTaxpayerManager.loadTaxpayer("123456789_INFO.txt");
    testTaxpayerManager.removeReceipt(1);
    assertEquals(false, testTaxpayerManager.getTaxpayerHashMapEntryValue().getReceiptHashMap().containsKey(1));
  }
}
