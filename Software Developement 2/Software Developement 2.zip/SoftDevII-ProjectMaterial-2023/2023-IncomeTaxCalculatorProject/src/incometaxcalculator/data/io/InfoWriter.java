package incometaxcalculator.data.io;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Iterator;

import incometaxcalculator.data.management.Receipt;
import incometaxcalculator.data.management.TaxpayerManager;

public abstract class InfoWriter implements FileWriter{

  String[] stringTagsGenerateFile = {"_INFO", "Name", 
      "AFM", "Status", "Income", "Receipts"};
  String[] stringTagsGenerateTaxpayer = {"Receipt ID", "Date", "Kind", "Amount", 
      "Company", "Country", "City", "Street", "Number"};
  
  public abstract String getStringConstants(String tag);
  public abstract String getStringConstantsForXML(String tag);
      
  public void generateFile(int taxRegistrationNumber) throws IOException {
    TaxpayerManager manager = new TaxpayerManager(); 

    PrintWriter outputStream = new PrintWriter(
        new java.io.FileWriter(taxRegistrationNumber + getStringConstants(stringTagsGenerateFile[0])));
    outputStream.println(getStringConstants(stringTagsGenerateFile[1]) + manager.getTaxpayerName(taxRegistrationNumber) + getStringConstantsForXML(stringTagsGenerateFile[1]));
    outputStream.println(getStringConstants(stringTagsGenerateFile[2]) + taxRegistrationNumber + getStringConstantsForXML(stringTagsGenerateFile[2]));
    outputStream.println(getStringConstants(stringTagsGenerateFile[3]) + manager.getTaxpayerStatus(taxRegistrationNumber) + getStringConstantsForXML(stringTagsGenerateFile[3]));
    outputStream.println(getStringConstants(stringTagsGenerateFile[4]) + manager.getTaxpayerIncome(taxRegistrationNumber) + getStringConstantsForXML(stringTagsGenerateFile[4]));
    outputStream.println();
    outputStream.println(getStringConstants(stringTagsGenerateFile[5]));
    outputStream.println();
    generateTaxpayerReceipts(taxRegistrationNumber, outputStream);
    outputStream.close();
  }
  
  private void generateTaxpayerReceipts(int taxRegistrationNumber, PrintWriter outputStream) {
    TaxpayerManager manager = new TaxpayerManager(); ////////

    HashMap<Integer, Receipt> receiptsHashMap = manager.getReceiptHashMap(taxRegistrationNumber);
    Iterator<HashMap.Entry<Integer, Receipt>> iterator = receiptsHashMap.entrySet().iterator();
    while (iterator.hasNext()) {
      HashMap.Entry<Integer, Receipt> entry = iterator.next();
      Receipt receipt = entry.getValue();
      outputStream.println(getStringConstants(stringTagsGenerateTaxpayer[0]) + getReceiptId(receipt) + getStringConstantsForXML(stringTagsGenerateTaxpayer[0]));
      outputStream.println(getStringConstants(stringTagsGenerateTaxpayer[1]) + getReceiptIssueDate(receipt) + getStringConstantsForXML(stringTagsGenerateTaxpayer[1]));
      outputStream.println(getStringConstants(stringTagsGenerateTaxpayer[2]) + getReceiptKind(receipt) + getStringConstantsForXML(stringTagsGenerateTaxpayer[2]));
      outputStream.println(getStringConstants(stringTagsGenerateTaxpayer[3]) + getReceiptAmount(receipt) + getStringConstantsForXML(stringTagsGenerateTaxpayer[3]));
      outputStream.println(getStringConstants(stringTagsGenerateTaxpayer[4]) + getCompanyName(receipt) + getStringConstantsForXML(stringTagsGenerateTaxpayer[4]));
      outputStream.println(getStringConstants(stringTagsGenerateTaxpayer[5]) + getCompanyCountry(receipt) + getStringConstantsForXML(stringTagsGenerateTaxpayer[5]));
      outputStream.println(getStringConstants(stringTagsGenerateTaxpayer[6]) + getCompanyCity(receipt) + getStringConstantsForXML(stringTagsGenerateTaxpayer[6]));
      outputStream.println(getStringConstants(stringTagsGenerateTaxpayer[7]) + getCompanyStreet(receipt) + getStringConstantsForXML(stringTagsGenerateTaxpayer[7]));
      outputStream.println(getStringConstants(stringTagsGenerateTaxpayer[8]) + getCompanyNumber(receipt) + getStringConstantsForXML(stringTagsGenerateTaxpayer[8]));
      outputStream.println();
    }
  }
  
  public int getReceiptId(Receipt receipt) {
    return receipt.getId();
  }
  
  public String getReceiptIssueDate(Receipt receipt) {
    return receipt.getIssueDate();
  }
  
  public String getReceiptKind(Receipt receipt) {
    return receipt.getKind();
  }
  
  public float getReceiptAmount(Receipt receipt) {
    return receipt.getAmount();
  }
  
  public String getCompanyName(Receipt receipt) {
    return receipt.getCompany().getName();
  }
  
  public String getCompanyCountry(Receipt receipt) {
    return receipt.getCompany().getCountry();
  }
  
  public String getCompanyCity(Receipt receipt) {
    return receipt.getCompany().getCity();
  }
  
  public String getCompanyStreet(Receipt receipt) {
    return receipt.getCompany().getStreet();
  }
  
  public int getCompanyNumber(Receipt receipt) {
    return receipt.getCompany().getNumber();
  }
}
